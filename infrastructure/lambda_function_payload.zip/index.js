
function test(event) {
    console.log("hello world" + event)
}